﻿import unittest
import os
import Airport_Simulation

class TestAirport_Simulation(unittest.TestCase):

    def setUp(self):
        pass

    def test(self):
        self.assertTrue(True)


    def test_vars_speeds(self):
        moveSpeed = 10
        turnSpeed = 10
        self.assertTrue(os.path.isfile("airport.png"), Error)







if __name__ == '__main__':
    unittest.main()