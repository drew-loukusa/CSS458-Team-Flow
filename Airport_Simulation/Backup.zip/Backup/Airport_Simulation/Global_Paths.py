
# This file contains all the possible paths that can be taken on this airport.
# It includes major runways, and taxiways




Runway_16R_34L = ()

Runway_16C_34C = ()

Runway_16L_34R = ()


