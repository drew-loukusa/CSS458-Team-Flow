

#==================================== NOTE ========================================#

	# Biggest thing we have to figure out is how big is each grid cell going to be.
	# We need to overlay a grid onto our image so we can start assigning coords to 
	# the terminals. 

	#The origin (0,0) for our grid will be in the bottom left of the image. As X goes right X increases. As Y goes up Y increases. 
	

	#Will do this tommorrow: 5/21/18
#==================================== NOTE ========================================#
